class WIS::DOM::ExpressedOpinion < WIS::DOM::Opinion			
end