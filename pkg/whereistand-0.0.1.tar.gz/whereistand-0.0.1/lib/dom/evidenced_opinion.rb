class WIS::DOM::EvidencedOpinion < WIS::DOM::Opinion			
end