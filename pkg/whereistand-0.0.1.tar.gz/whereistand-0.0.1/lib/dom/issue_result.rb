class WIS::DOM::IssueResult
	attr_accessor :issue, :unknown, :unverified, :approved
	
end