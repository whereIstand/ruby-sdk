class WIS::DOM::UnknownOpinion < WIS::DOM::Opinion
	def initialize(issue)
		@issue = issue
	end			
end