class WIS::DOM::ApprovedOpinion < WIS::DOM::EvidencedOpinion
end