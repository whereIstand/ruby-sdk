class WIS::DOM::UnverifiedOpinion < WIS::DOM::EvidencedOpinion			
end